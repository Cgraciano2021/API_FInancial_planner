# Unit 5 - Financial Planning


```python
# Initial imports
import os
import requests
import pandas as pd
from dotenv import load_dotenv
import alpaca_trade_api as tradeapi
from MCForecastTools import MCSimulation

%matplotlib inline
```


```python
# Load .env enviroment variables
load_dotenv()
```




    True



## Part 1 - Personal Finance Planner

### Collect Crypto Prices Using the `requests` Library


```python
# Set current amount of crypto assets
my_btc = 1.2
my_eth = 5.3
```


```python
# Crypto API URLs
btc_url = "https://api.alternative.me/v2/ticker/Bitcoin/?convert=CAD"
eth_url = "https://api.alternative.me/v2/ticker/Ethereum/?convert=CAD"
```


```python
# Fetch current BTC price
btc_response = requests.get(btc_url).json()
btc_price = btc_response["data"]["1"]["quotes"]["CAD"]["price"]

# Fetch current ETH price
eth_response = requests.get(eth_url).json()
eth_price = eth_response["data"]["1027"]["quotes"]["CAD"]["price"]

# Compute current value of my crpto
my_btc_value = my_btc * btc_price
my_eth_value = my_eth * eth_price

# Print current crypto wallet balance
print(f"The current value of your {my_btc} BTC is ${my_btc_value:0.2f}")
print(f"The current value of your {my_eth} ETH is ${my_eth_value:0.2f}")
```

    The current value of your 1.2 BTC is $58442.26
    The current value of your 5.3 ETH is $18339.46


### Collect Investments Data Using Alpaca: `SPY` (stocks) and `AGG` (bonds)


```python
# Set current amount of shares
my_agg = 200
my_spy = 50
```


```python
# Set Alpaca API key and secret
alpaca_api_key = os.getenv("ALPACA_API_KEY")
alpaca_secret_key = os.getenv("ALPACA_SECRET_KEY")

# Create the Alpaca API object
alpaca = tradeapi.REST(
    alpaca_api_key,
    alpaca_secret_key,
    api_version="v2")
```


```python
# Format current date as ISO format
today = pd.Timestamp("2022-01-01", tz="America/New_York").isoformat()

# Set the tickers
tickers = ["AGG", "SPY"]

# Set timeframe to '1D' for Alpaca API
timeframe = "1D"

# Get current closing prices for SPY and AGG
# (use a limit=1000 parameter to call the most recent 1000 days of data)
df_investments = alpaca.get_barset(
    tickers,
    timeframe,
    start = today,
    limit=1000
).df

# Preview DataFrame
df_investments.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="5" halign="left">AGG</th>
      <th colspan="5" halign="left">SPY</th>
    </tr>
    <tr>
      <th></th>
      <th>open</th>
      <th>high</th>
      <th>low</th>
      <th>close</th>
      <th>volume</th>
      <th>open</th>
      <th>high</th>
      <th>low</th>
      <th>close</th>
      <th>volume</th>
    </tr>
    <tr>
      <th>time</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2022-01-03 00:00:00-05:00</th>
      <td>113.67</td>
      <td>113.6753</td>
      <td>113.310</td>
      <td>113.31</td>
      <td>8906643</td>
      <td>476.32</td>
      <td>477.85</td>
      <td>473.8500</td>
      <td>477.76</td>
      <td>56128214</td>
    </tr>
    <tr>
      <th>2022-01-04 00:00:00-05:00</th>
      <td>113.22</td>
      <td>113.3000</td>
      <td>113.075</td>
      <td>113.29</td>
      <td>7615698</td>
      <td>479.22</td>
      <td>479.98</td>
      <td>475.5800</td>
      <td>477.51</td>
      <td>59093344</td>
    </tr>
    <tr>
      <th>2022-01-05 00:00:00-05:00</th>
      <td>113.34</td>
      <td>113.3600</td>
      <td>112.900</td>
      <td>112.93</td>
      <td>7686662</td>
      <td>477.16</td>
      <td>477.98</td>
      <td>468.2801</td>
      <td>468.38</td>
      <td>87411658</td>
    </tr>
    <tr>
      <th>2022-01-06 00:00:00-05:00</th>
      <td>112.75</td>
      <td>112.8400</td>
      <td>112.660</td>
      <td>112.81</td>
      <td>6812819</td>
      <td>467.89</td>
      <td>470.82</td>
      <td>465.4300</td>
      <td>467.93</td>
      <td>78577470</td>
    </tr>
    <tr>
      <th>2022-01-07 00:00:00-05:00</th>
      <td>112.69</td>
      <td>112.7050</td>
      <td>112.340</td>
      <td>112.50</td>
      <td>8338975</td>
      <td>467.95</td>
      <td>469.20</td>
      <td>464.6500</td>
      <td>466.12</td>
      <td>67943055</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Pick AGG and SPY close prices
agg_close_price = float(df_investments["AGG"]["close"][0])
spy_close_price = float(df_investments["SPY"]["close"][0])

# Print AGG and SPY close prices
print(f"Current AGG closing price: ${agg_close_price}")
print(f"Current SPY closing price: ${spy_close_price}")
```

    Current AGG closing price: $113.31
    Current SPY closing price: $477.76



```python
# Compute the current value of shares
my_spy_value = my_spy * spy_close_price
my_agg_value = my_agg * agg_close_price

# Print current value of shares
print(f"The current value of your {my_spy} SPY shares is ${my_spy_value:0.2f}")
print(f"The current value of your {my_agg} AGG shares is ${my_agg_value:0.2f}")
```

    The current value of your 50 SPY shares is $23888.00
    The current value of your 200 AGG shares is $22662.00


### Savings Health Analysis


```python
# Set monthly household income
monthly_income = 12000

# Consolidate financial assets data
savings_data = [
    my_btc_value + my_eth_value,
    my_spy_value + my_agg_value,
]

# Create savings DataFrame
df_savings = pd.DataFrame(savings_data, columns=["amount"], index=["crypto", "shares"])

# Display savings DataFrame
display(df_savings)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>crypto</th>
      <td>76781.718671</td>
    </tr>
    <tr>
      <th>shares</th>
      <td>46550.000000</td>
    </tr>
  </tbody>
</table>
</div>



```python
# Plot savings pie chart
df_savings.plot.pie(y="amount", title="Composition of Personal Savings")
```




    <AxesSubplot:title={'center':'Composition of Personal Savings'}, ylabel='amount'>




    
![png](output_16_1.png)
    



```python
# Set ideal emergency fund
emergency_fund = monthly_income * 3

# Calculate total amount of savings
total_savings = float(df_savings.sum())

# Validate saving health
if total_savings > emergency_fund:
    print("Congratulations! You have enough money in your emergency fund.")
elif total_savings == emergency_fund:
    print("Great, You have saved three times your monthly expenses! Keep pushing to increase your savings.")
else:
    print(f"You are ${(emergency_fund - total_savings):0.2f} away from your emergency fund goal, continue saving between 10% and 20% of your monthly income to reach your goal.")
```

    Congratulations! You have enough money in your emergency fund.


## Part 2 - Retirement Planning

### Monte Carlo Simulation


```python
# Set start and end dates of five years back from today.
# Sample results may vary from the solution based on the time frame chosen
start_date = pd.Timestamp('2017-01-01', tz='America/New_York').isoformat()
end_date = pd.Timestamp('2022-01-01', tz='America/New_York').isoformat()
```


```python
# Get 5 years' worth of historical data for SPY and AGG
# (use a limit=1000 parameter to call the most recent 1000 days of data)
df_stock_data = alpaca.get_barset(
    tickers,
    timeframe,
    start=start_date,
    end=end_date,
    limit=1000
).df


# Display sample data
df_stock_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="5" halign="left">AGG</th>
      <th colspan="5" halign="left">SPY</th>
    </tr>
    <tr>
      <th></th>
      <th>open</th>
      <th>high</th>
      <th>low</th>
      <th>close</th>
      <th>volume</th>
      <th>open</th>
      <th>high</th>
      <th>low</th>
      <th>close</th>
      <th>volume</th>
    </tr>
    <tr>
      <th>time</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2018-01-12 00:00:00-05:00</th>
      <td>108.64</td>
      <td>108.830</td>
      <td>108.630</td>
      <td>108.7401</td>
      <td>2950016</td>
      <td>276.42</td>
      <td>278.11</td>
      <td>276.27</td>
      <td>277.91</td>
      <td>53855427</td>
    </tr>
    <tr>
      <th>2018-01-16 00:00:00-05:00</th>
      <td>108.87</td>
      <td>108.980</td>
      <td>108.715</td>
      <td>108.7600</td>
      <td>6011248</td>
      <td>279.35</td>
      <td>280.09</td>
      <td>276.18</td>
      <td>276.96</td>
      <td>70240852</td>
    </tr>
    <tr>
      <th>2018-01-17 00:00:00-05:00</th>
      <td>108.73</td>
      <td>108.839</td>
      <td>108.620</td>
      <td>108.6500</td>
      <td>2880481</td>
      <td>278.04</td>
      <td>280.05</td>
      <td>277.19</td>
      <td>279.61</td>
      <td>62162956</td>
    </tr>
    <tr>
      <th>2018-01-18 00:00:00-05:00</th>
      <td>108.43</td>
      <td>108.525</td>
      <td>108.350</td>
      <td>108.3800</td>
      <td>2681682</td>
      <td>279.50</td>
      <td>279.96</td>
      <td>278.58</td>
      <td>279.18</td>
      <td>57402163</td>
    </tr>
    <tr>
      <th>2018-01-19 00:00:00-05:00</th>
      <td>108.40</td>
      <td>108.400</td>
      <td>108.140</td>
      <td>108.1500</td>
      <td>2751607</td>
      <td>279.80</td>
      <td>280.40</td>
      <td>279.14</td>
      <td>280.38</td>
      <td>55178145</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Configuring a Monte Carlo simulation to forecast 30 years cumulative returns
MC_thirty_year = MCSimulation(
    portfolio_data = df_stock_data,
    weights = [.40,.60],
    num_simulation = 500,
    num_trading_days = 252 * 30
)
```


```python
# Printing the simulation input data
MC_thirty_year.portfolio_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="6" halign="left">AGG</th>
      <th colspan="6" halign="left">SPY</th>
    </tr>
    <tr>
      <th></th>
      <th>open</th>
      <th>high</th>
      <th>low</th>
      <th>close</th>
      <th>volume</th>
      <th>daily_return</th>
      <th>open</th>
      <th>high</th>
      <th>low</th>
      <th>close</th>
      <th>volume</th>
      <th>daily_return</th>
    </tr>
    <tr>
      <th>time</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2018-01-12 00:00:00-05:00</th>
      <td>108.64</td>
      <td>108.830</td>
      <td>108.630</td>
      <td>108.7401</td>
      <td>2950016</td>
      <td>NaN</td>
      <td>276.42</td>
      <td>278.11</td>
      <td>276.27</td>
      <td>277.91</td>
      <td>53855427</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2018-01-16 00:00:00-05:00</th>
      <td>108.87</td>
      <td>108.980</td>
      <td>108.715</td>
      <td>108.7600</td>
      <td>6011248</td>
      <td>0.000183</td>
      <td>279.35</td>
      <td>280.09</td>
      <td>276.18</td>
      <td>276.96</td>
      <td>70240852</td>
      <td>-0.003418</td>
    </tr>
    <tr>
      <th>2018-01-17 00:00:00-05:00</th>
      <td>108.73</td>
      <td>108.839</td>
      <td>108.620</td>
      <td>108.6500</td>
      <td>2880481</td>
      <td>-0.001011</td>
      <td>278.04</td>
      <td>280.05</td>
      <td>277.19</td>
      <td>279.61</td>
      <td>62162956</td>
      <td>0.009568</td>
    </tr>
    <tr>
      <th>2018-01-18 00:00:00-05:00</th>
      <td>108.43</td>
      <td>108.525</td>
      <td>108.350</td>
      <td>108.3800</td>
      <td>2681682</td>
      <td>-0.002485</td>
      <td>279.50</td>
      <td>279.96</td>
      <td>278.58</td>
      <td>279.18</td>
      <td>57402163</td>
      <td>-0.001538</td>
    </tr>
    <tr>
      <th>2018-01-19 00:00:00-05:00</th>
      <td>108.40</td>
      <td>108.400</td>
      <td>108.140</td>
      <td>108.1500</td>
      <td>2751607</td>
      <td>-0.002122</td>
      <td>279.80</td>
      <td>280.40</td>
      <td>279.14</td>
      <td>280.38</td>
      <td>55178145</td>
      <td>0.004298</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Running a Monte Carlo simulation to forecast 30 years cumulative returns
MC_thirty_year.calc_cumulative_return()
```

    Running Monte Carlo simulation number 0.
    Running Monte Carlo simulation number 10.
    Running Monte Carlo simulation number 20.
    Running Monte Carlo simulation number 30.
    Running Monte Carlo simulation number 40.
    Running Monte Carlo simulation number 50.
    Running Monte Carlo simulation number 60.
    Running Monte Carlo simulation number 70.
    Running Monte Carlo simulation number 80.
    Running Monte Carlo simulation number 90.
    Running Monte Carlo simulation number 100.


    /Users/corygraciano/Desktop/ASU10_16/Home Work/05-APIs/Solutions/MCForecastTools.py:117: PerformanceWarning: DataFrame is highly fragmented.  This is usually the result of calling `frame.insert` many times, which has poor performance.  Consider joining all columns at once using pd.concat(axis=1) instead.  To get a de-fragmented frame, use `newframe = frame.copy()`
      portfolio_cumulative_returns[n] = (1 + sim_df.fillna(0)).cumprod()


    Running Monte Carlo simulation number 110.
    Running Monte Carlo simulation number 120.
    Running Monte Carlo simulation number 130.
    Running Monte Carlo simulation number 140.
    Running Monte Carlo simulation number 150.
    Running Monte Carlo simulation number 160.
    Running Monte Carlo simulation number 170.
    Running Monte Carlo simulation number 180.
    Running Monte Carlo simulation number 190.
    Running Monte Carlo simulation number 200.
    Running Monte Carlo simulation number 210.
    Running Monte Carlo simulation number 220.
    Running Monte Carlo simulation number 230.
    Running Monte Carlo simulation number 240.
    Running Monte Carlo simulation number 250.
    Running Monte Carlo simulation number 260.
    Running Monte Carlo simulation number 270.
    Running Monte Carlo simulation number 280.
    Running Monte Carlo simulation number 290.
    Running Monte Carlo simulation number 300.
    Running Monte Carlo simulation number 310.
    Running Monte Carlo simulation number 320.
    Running Monte Carlo simulation number 330.
    Running Monte Carlo simulation number 340.
    Running Monte Carlo simulation number 350.
    Running Monte Carlo simulation number 360.
    Running Monte Carlo simulation number 370.
    Running Monte Carlo simulation number 380.
    Running Monte Carlo simulation number 390.
    Running Monte Carlo simulation number 400.
    Running Monte Carlo simulation number 410.
    Running Monte Carlo simulation number 420.
    Running Monte Carlo simulation number 430.
    Running Monte Carlo simulation number 440.
    Running Monte Carlo simulation number 450.
    Running Monte Carlo simulation number 460.
    Running Monte Carlo simulation number 470.
    Running Monte Carlo simulation number 480.
    Running Monte Carlo simulation number 490.





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>...</th>
      <th>490</th>
      <th>491</th>
      <th>492</th>
      <th>493</th>
      <th>494</th>
      <th>495</th>
      <th>496</th>
      <th>497</th>
      <th>498</th>
      <th>499</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.007822</td>
      <td>0.996069</td>
      <td>1.005700</td>
      <td>1.013472</td>
      <td>0.993465</td>
      <td>1.002099</td>
      <td>1.000594</td>
      <td>1.011461</td>
      <td>1.008299</td>
      <td>0.997116</td>
      <td>...</td>
      <td>1.010845</td>
      <td>0.987610</td>
      <td>0.998823</td>
      <td>1.018856</td>
      <td>1.002799</td>
      <td>0.987554</td>
      <td>0.997767</td>
      <td>0.987022</td>
      <td>1.002566</td>
      <td>0.996706</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.008055</td>
      <td>0.990045</td>
      <td>0.992429</td>
      <td>1.015086</td>
      <td>1.005329</td>
      <td>0.996610</td>
      <td>0.996057</td>
      <td>0.999185</td>
      <td>1.011501</td>
      <td>1.007079</td>
      <td>...</td>
      <td>1.020592</td>
      <td>0.988301</td>
      <td>0.993477</td>
      <td>1.035992</td>
      <td>0.991743</td>
      <td>1.003166</td>
      <td>1.005506</td>
      <td>0.965542</td>
      <td>1.005101</td>
      <td>0.989222</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.998264</td>
      <td>0.979132</td>
      <td>0.983803</td>
      <td>1.009274</td>
      <td>1.022377</td>
      <td>1.003258</td>
      <td>1.000676</td>
      <td>1.003500</td>
      <td>1.012783</td>
      <td>1.008094</td>
      <td>...</td>
      <td>1.020084</td>
      <td>0.998632</td>
      <td>0.997895</td>
      <td>1.024437</td>
      <td>0.997950</td>
      <td>0.986159</td>
      <td>0.991086</td>
      <td>0.966351</td>
      <td>1.007155</td>
      <td>0.989330</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.007090</td>
      <td>0.989628</td>
      <td>0.977080</td>
      <td>1.003360</td>
      <td>1.031813</td>
      <td>0.997616</td>
      <td>1.004298</td>
      <td>1.001271</td>
      <td>1.017842</td>
      <td>1.006249</td>
      <td>...</td>
      <td>1.025667</td>
      <td>1.004602</td>
      <td>0.994067</td>
      <td>1.025665</td>
      <td>0.985866</td>
      <td>0.979413</td>
      <td>0.994225</td>
      <td>0.973283</td>
      <td>1.002824</td>
      <td>1.002204</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>7556</th>
      <td>4.522596</td>
      <td>58.883620</td>
      <td>36.211426</td>
      <td>4.842523</td>
      <td>47.428704</td>
      <td>7.328765</td>
      <td>18.550011</td>
      <td>13.948623</td>
      <td>14.225132</td>
      <td>14.209974</td>
      <td>...</td>
      <td>6.780721</td>
      <td>16.706758</td>
      <td>12.252299</td>
      <td>15.383592</td>
      <td>23.173086</td>
      <td>31.226040</td>
      <td>9.752907</td>
      <td>7.720254</td>
      <td>15.642796</td>
      <td>34.303207</td>
    </tr>
    <tr>
      <th>7557</th>
      <td>4.508979</td>
      <td>59.293398</td>
      <td>36.571300</td>
      <td>4.824112</td>
      <td>48.128689</td>
      <td>7.342958</td>
      <td>18.171164</td>
      <td>13.779312</td>
      <td>14.080680</td>
      <td>14.152909</td>
      <td>...</td>
      <td>6.762177</td>
      <td>16.672384</td>
      <td>12.279114</td>
      <td>15.581089</td>
      <td>23.179567</td>
      <td>31.362417</td>
      <td>9.775379</td>
      <td>7.598319</td>
      <td>15.491877</td>
      <td>34.156111</td>
    </tr>
    <tr>
      <th>7558</th>
      <td>4.469938</td>
      <td>59.372453</td>
      <td>36.073229</td>
      <td>4.830997</td>
      <td>48.047849</td>
      <td>7.240056</td>
      <td>18.236831</td>
      <td>13.975284</td>
      <td>14.200270</td>
      <td>14.242081</td>
      <td>...</td>
      <td>6.841559</td>
      <td>16.657516</td>
      <td>12.369098</td>
      <td>15.641693</td>
      <td>23.140534</td>
      <td>31.174110</td>
      <td>9.698289</td>
      <td>7.612963</td>
      <td>15.524486</td>
      <td>34.507209</td>
    </tr>
    <tr>
      <th>7559</th>
      <td>4.394912</td>
      <td>59.792263</td>
      <td>35.326937</td>
      <td>4.859739</td>
      <td>47.523751</td>
      <td>7.136156</td>
      <td>18.165248</td>
      <td>14.167594</td>
      <td>14.140160</td>
      <td>14.165808</td>
      <td>...</td>
      <td>6.904013</td>
      <td>16.863578</td>
      <td>12.236409</td>
      <td>15.697720</td>
      <td>23.200718</td>
      <td>31.023338</td>
      <td>9.629984</td>
      <td>7.532337</td>
      <td>15.835213</td>
      <td>34.943552</td>
    </tr>
    <tr>
      <th>7560</th>
      <td>4.384012</td>
      <td>59.926101</td>
      <td>35.671360</td>
      <td>4.855088</td>
      <td>46.879957</td>
      <td>7.126843</td>
      <td>18.200773</td>
      <td>14.068202</td>
      <td>14.030643</td>
      <td>14.232408</td>
      <td>...</td>
      <td>6.920912</td>
      <td>16.950097</td>
      <td>12.124989</td>
      <td>15.773457</td>
      <td>23.210806</td>
      <td>31.033756</td>
      <td>9.563250</td>
      <td>7.559814</td>
      <td>16.080891</td>
      <td>34.862159</td>
    </tr>
  </tbody>
</table>
<p>7561 rows × 500 columns</p>
</div>




```python
# Plot simulation outcomes
line_plot = MC_thirty_year.plot_simulation()
```


    
![png](output_24_0.png)
    



```python
# Plot probability distribution and confidence intervals
dist_plot = MC_thirty_year.plot_distribution()
```


    
![png](output_25_0.png)
    


### Retirement Analysis


```python
# Fetch summary statistics from the Monte Carlo simulation results
tbl = MC_thirty_year.summarize_cumulative_return()

# Print summary statistics
print(tbl)
```

    count           500.000000
    mean             20.721351
    std              16.998504
    min               1.793499
    25%               9.977953
    50%              16.409330
    75%              25.448958
    max             155.918151
    95% CI Lower      4.270742
    95% CI Upper     65.122821
    Name: 7560, dtype: float64


### Calculate the expected portfolio return at the `95%` lower and upper confidence intervals based on a `$20,000` initial investment.


```python
# Set initial investment
initial_investment = 20000

# Use the lower and upper `95%` confidence intervals to calculate the range of the possible outcomes of our $20,000
ci_lower = round(tbl[8] * initial_investment,2)
ci_upper = round(tbl[9] * initial_investment,2)

# Print results
print(f"There is a 95% chance that an initial investment of ${initial_investment} in the portfolio"
      f" over the next 30 years will end within in the range of"
      f" ${ci_lower} and ${ci_upper}")
```

    There is a 95% chance that an initial investment of $20000 in the portfolio over the next 30 years will end within in the range of $85414.85 and $1302456.41


### Calculate the expected portfolio return at the `95%` lower and upper confidence intervals based on a `50%` increase in the initial investment.


```python
# Set initial investment
initial_investment = 20000 * 1.5

# Use the lower and upper `95%` confidence intervals to calculate the range of the possible outcomes of our $30,000
ci_lower = round(tbl[8] * initial_investment,2)
ci_upper = round(tbl[9] * initial_investment,2)

# Print results
print(f"There is a 95% chance that an initial investment of ${initial_investment} in the portfolio"
      f" over the next 30 years will end within in the range of"
      f" ${ci_lower} and ${ci_upper}")
```

    There is a 95% chance that an initial investment of $30000.0 in the portfolio over the next 30 years will end within in the range of $128122.27 and $1953684.62


## Optional Challenge - Early Retirement


### Five Years Retirement Option


```python
# Configuring a Monte Carlo simulation to forecast 5 years cumulative returns
MC_five_year = MCSimulation(
    portfolio_data = df_stock_data,
    weights = [.80,.20],
    num_simulation = 500,
    num_trading_days = 252 * 5
)
```


```python
# Running a Monte Carlo simulation to forecast 5 years cumulative returns
MC_five_year.calc_cumulative_return()
```

    Running Monte Carlo simulation number 0.
    Running Monte Carlo simulation number 10.
    Running Monte Carlo simulation number 20.
    Running Monte Carlo simulation number 30.
    Running Monte Carlo simulation number 40.
    Running Monte Carlo simulation number 50.
    Running Monte Carlo simulation number 60.
    Running Monte Carlo simulation number 70.
    Running Monte Carlo simulation number 80.
    Running Monte Carlo simulation number 90.
    Running Monte Carlo simulation number 100.


    /Users/corygraciano/Desktop/ASU10_16/Home Work/05-APIs/Solutions/MCForecastTools.py:117: PerformanceWarning: DataFrame is highly fragmented.  This is usually the result of calling `frame.insert` many times, which has poor performance.  Consider joining all columns at once using pd.concat(axis=1) instead.  To get a de-fragmented frame, use `newframe = frame.copy()`
      portfolio_cumulative_returns[n] = (1 + sim_df.fillna(0)).cumprod()


    Running Monte Carlo simulation number 110.
    Running Monte Carlo simulation number 120.
    Running Monte Carlo simulation number 130.
    Running Monte Carlo simulation number 140.
    Running Monte Carlo simulation number 150.
    Running Monte Carlo simulation number 160.
    Running Monte Carlo simulation number 170.
    Running Monte Carlo simulation number 180.
    Running Monte Carlo simulation number 190.
    Running Monte Carlo simulation number 200.
    Running Monte Carlo simulation number 210.
    Running Monte Carlo simulation number 220.
    Running Monte Carlo simulation number 230.
    Running Monte Carlo simulation number 240.
    Running Monte Carlo simulation number 250.
    Running Monte Carlo simulation number 260.
    Running Monte Carlo simulation number 270.
    Running Monte Carlo simulation number 280.
    Running Monte Carlo simulation number 290.
    Running Monte Carlo simulation number 300.
    Running Monte Carlo simulation number 310.
    Running Monte Carlo simulation number 320.
    Running Monte Carlo simulation number 330.
    Running Monte Carlo simulation number 340.
    Running Monte Carlo simulation number 350.
    Running Monte Carlo simulation number 360.
    Running Monte Carlo simulation number 370.
    Running Monte Carlo simulation number 380.
    Running Monte Carlo simulation number 390.
    Running Monte Carlo simulation number 400.
    Running Monte Carlo simulation number 410.
    Running Monte Carlo simulation number 420.
    Running Monte Carlo simulation number 430.
    Running Monte Carlo simulation number 440.
    Running Monte Carlo simulation number 450.
    Running Monte Carlo simulation number 460.
    Running Monte Carlo simulation number 470.
    Running Monte Carlo simulation number 480.
    Running Monte Carlo simulation number 490.





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>...</th>
      <th>490</th>
      <th>491</th>
      <th>492</th>
      <th>493</th>
      <th>494</th>
      <th>495</th>
      <th>496</th>
      <th>497</th>
      <th>498</th>
      <th>499</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.002955</td>
      <td>0.995196</td>
      <td>1.002280</td>
      <td>0.998822</td>
      <td>0.997195</td>
      <td>0.998522</td>
      <td>0.994426</td>
      <td>1.001856</td>
      <td>0.993788</td>
      <td>1.002417</td>
      <td>...</td>
      <td>0.996521</td>
      <td>1.000589</td>
      <td>0.994629</td>
      <td>1.001687</td>
      <td>1.003986</td>
      <td>1.000530</td>
      <td>1.003926</td>
      <td>0.995326</td>
      <td>0.997655</td>
      <td>1.001967</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.003633</td>
      <td>0.992671</td>
      <td>1.002414</td>
      <td>0.995209</td>
      <td>0.992239</td>
      <td>0.994822</td>
      <td>0.985848</td>
      <td>1.007774</td>
      <td>0.992300</td>
      <td>1.001255</td>
      <td>...</td>
      <td>1.000397</td>
      <td>1.005138</td>
      <td>0.991735</td>
      <td>0.994718</td>
      <td>0.999259</td>
      <td>0.989503</td>
      <td>1.004865</td>
      <td>0.993176</td>
      <td>0.994885</td>
      <td>1.007257</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.005493</td>
      <td>0.993616</td>
      <td>1.000947</td>
      <td>0.998234</td>
      <td>0.988995</td>
      <td>1.002724</td>
      <td>0.981726</td>
      <td>1.011020</td>
      <td>0.996394</td>
      <td>1.002066</td>
      <td>...</td>
      <td>0.997937</td>
      <td>1.010897</td>
      <td>0.987609</td>
      <td>0.991162</td>
      <td>0.996904</td>
      <td>0.983155</td>
      <td>1.002796</td>
      <td>0.995571</td>
      <td>0.992723</td>
      <td>1.002992</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.008874</td>
      <td>0.990858</td>
      <td>1.000417</td>
      <td>1.004779</td>
      <td>0.989616</td>
      <td>1.010470</td>
      <td>0.988760</td>
      <td>1.018332</td>
      <td>0.991814</td>
      <td>0.997925</td>
      <td>...</td>
      <td>0.993417</td>
      <td>1.011410</td>
      <td>0.983847</td>
      <td>0.992500</td>
      <td>0.995933</td>
      <td>0.980845</td>
      <td>0.998583</td>
      <td>0.992302</td>
      <td>0.994462</td>
      <td>1.001315</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1256</th>
      <td>1.179966</td>
      <td>1.066890</td>
      <td>1.275250</td>
      <td>1.178840</td>
      <td>1.342546</td>
      <td>1.443156</td>
      <td>1.177752</td>
      <td>1.268961</td>
      <td>1.222953</td>
      <td>1.092174</td>
      <td>...</td>
      <td>1.531160</td>
      <td>1.199935</td>
      <td>1.123329</td>
      <td>1.225404</td>
      <td>1.217650</td>
      <td>1.347598</td>
      <td>1.191139</td>
      <td>1.544687</td>
      <td>1.417092</td>
      <td>1.100918</td>
    </tr>
    <tr>
      <th>1257</th>
      <td>1.174247</td>
      <td>1.058458</td>
      <td>1.274244</td>
      <td>1.173439</td>
      <td>1.335432</td>
      <td>1.436372</td>
      <td>1.174910</td>
      <td>1.264692</td>
      <td>1.223804</td>
      <td>1.091538</td>
      <td>...</td>
      <td>1.537658</td>
      <td>1.201638</td>
      <td>1.121006</td>
      <td>1.223785</td>
      <td>1.218709</td>
      <td>1.357731</td>
      <td>1.198273</td>
      <td>1.547120</td>
      <td>1.412465</td>
      <td>1.095615</td>
    </tr>
    <tr>
      <th>1258</th>
      <td>1.170180</td>
      <td>1.057204</td>
      <td>1.276884</td>
      <td>1.173584</td>
      <td>1.334980</td>
      <td>1.439266</td>
      <td>1.169632</td>
      <td>1.264139</td>
      <td>1.231005</td>
      <td>1.099496</td>
      <td>...</td>
      <td>1.530372</td>
      <td>1.204803</td>
      <td>1.122281</td>
      <td>1.219561</td>
      <td>1.212137</td>
      <td>1.357440</td>
      <td>1.199301</td>
      <td>1.548725</td>
      <td>1.405741</td>
      <td>1.087188</td>
    </tr>
    <tr>
      <th>1259</th>
      <td>1.167852</td>
      <td>1.050752</td>
      <td>1.274626</td>
      <td>1.170907</td>
      <td>1.338328</td>
      <td>1.441359</td>
      <td>1.168161</td>
      <td>1.256296</td>
      <td>1.231200</td>
      <td>1.098920</td>
      <td>...</td>
      <td>1.531021</td>
      <td>1.203161</td>
      <td>1.123334</td>
      <td>1.220613</td>
      <td>1.211057</td>
      <td>1.357223</td>
      <td>1.196227</td>
      <td>1.540782</td>
      <td>1.399105</td>
      <td>1.088146</td>
    </tr>
    <tr>
      <th>1260</th>
      <td>1.166784</td>
      <td>1.043160</td>
      <td>1.278365</td>
      <td>1.173790</td>
      <td>1.343177</td>
      <td>1.447076</td>
      <td>1.163413</td>
      <td>1.250705</td>
      <td>1.230104</td>
      <td>1.098993</td>
      <td>...</td>
      <td>1.537005</td>
      <td>1.206504</td>
      <td>1.124957</td>
      <td>1.214147</td>
      <td>1.217027</td>
      <td>1.363014</td>
      <td>1.198810</td>
      <td>1.538361</td>
      <td>1.406309</td>
      <td>1.093884</td>
    </tr>
  </tbody>
</table>
<p>1261 rows × 500 columns</p>
</div>




```python
# Plot simulation outcomes
line_plot_five = MC_five_year.plot_simulation()
```


    
![png](output_35_0.png)
    



```python
# Plot probability distribution and confidence intervals
dist_plot_five = MC_five_year.plot_distribution()
```


    
![png](output_36_0.png)
    



```python
# Fetch summary statistics from the Monte Carlo simulation results
tbl_five = MC_five_year.summarize_cumulative_return()

# Print summary statistics
print(tbl_five)
```

    count           500.000000
    mean              1.227292
    std               0.163142
    min               0.848028
    25%               1.111581
    50%               1.224994
    75%               1.336653
    max               1.715614
    95% CI Lower      0.939369
    95% CI Upper      1.555376
    Name: 1260, dtype: float64



```python
# Set initial investment
initial_investment = 20000 * 3

# Use the lower and upper `95%` confidence intervals to calculate the range of the possible outcomes of our $60,000
ci_lower_five = round(tbl_five[8] * initial_investment,2)
ci_upper_five = round(tbl_five[9] * initial_investment,2)

# Print results
print(f"There is a 95% chance that an initial investment of ${initial_investment} in the portfolio"
      f" over the next 5 years will end within in the range of"
      f" ${ci_lower_five} and ${ci_upper_five}")
```

    There is a 95% chance that an initial investment of $60000 in the portfolio over the next 5 years will end within in the range of $56362.15 and $93322.58


### Ten Years Retirement Option


```python
# Configuring a Monte Carlo simulation to forecast 10 years cumulative returns
MC_ten_year = MCSimulation(
    portfolio_data = df_stock_data,
    weights = [.80,.20],
    num_simulation = 500,
    num_trading_days = 252 * 10
)
```


```python
# Running a Monte Carlo simulation to forecast 10 years cumulative returns
MC_ten_year.calc_cumulative_return()
```

    Running Monte Carlo simulation number 0.
    Running Monte Carlo simulation number 10.
    Running Monte Carlo simulation number 20.
    Running Monte Carlo simulation number 30.
    Running Monte Carlo simulation number 40.
    Running Monte Carlo simulation number 50.
    Running Monte Carlo simulation number 60.
    Running Monte Carlo simulation number 70.
    Running Monte Carlo simulation number 80.
    Running Monte Carlo simulation number 90.
    Running Monte Carlo simulation number 100.


    /Users/corygraciano/Desktop/ASU10_16/Home Work/05-APIs/Solutions/MCForecastTools.py:117: PerformanceWarning: DataFrame is highly fragmented.  This is usually the result of calling `frame.insert` many times, which has poor performance.  Consider joining all columns at once using pd.concat(axis=1) instead.  To get a de-fragmented frame, use `newframe = frame.copy()`
      portfolio_cumulative_returns[n] = (1 + sim_df.fillna(0)).cumprod()


    Running Monte Carlo simulation number 110.
    Running Monte Carlo simulation number 120.
    Running Monte Carlo simulation number 130.
    Running Monte Carlo simulation number 140.
    Running Monte Carlo simulation number 150.
    Running Monte Carlo simulation number 160.
    Running Monte Carlo simulation number 170.
    Running Monte Carlo simulation number 180.
    Running Monte Carlo simulation number 190.
    Running Monte Carlo simulation number 200.
    Running Monte Carlo simulation number 210.
    Running Monte Carlo simulation number 220.
    Running Monte Carlo simulation number 230.
    Running Monte Carlo simulation number 240.
    Running Monte Carlo simulation number 250.
    Running Monte Carlo simulation number 260.
    Running Monte Carlo simulation number 270.
    Running Monte Carlo simulation number 280.
    Running Monte Carlo simulation number 290.
    Running Monte Carlo simulation number 300.
    Running Monte Carlo simulation number 310.
    Running Monte Carlo simulation number 320.
    Running Monte Carlo simulation number 330.
    Running Monte Carlo simulation number 340.
    Running Monte Carlo simulation number 350.
    Running Monte Carlo simulation number 360.
    Running Monte Carlo simulation number 370.
    Running Monte Carlo simulation number 380.
    Running Monte Carlo simulation number 390.
    Running Monte Carlo simulation number 400.
    Running Monte Carlo simulation number 410.
    Running Monte Carlo simulation number 420.
    Running Monte Carlo simulation number 430.
    Running Monte Carlo simulation number 440.
    Running Monte Carlo simulation number 450.
    Running Monte Carlo simulation number 460.
    Running Monte Carlo simulation number 470.
    Running Monte Carlo simulation number 480.
    Running Monte Carlo simulation number 490.





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>...</th>
      <th>490</th>
      <th>491</th>
      <th>492</th>
      <th>493</th>
      <th>494</th>
      <th>495</th>
      <th>496</th>
      <th>497</th>
      <th>498</th>
      <th>499</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.001788</td>
      <td>0.996994</td>
      <td>1.000247</td>
      <td>1.007769</td>
      <td>1.003637</td>
      <td>0.997295</td>
      <td>0.998809</td>
      <td>0.998416</td>
      <td>1.004314</td>
      <td>0.999727</td>
      <td>...</td>
      <td>0.998031</td>
      <td>0.992712</td>
      <td>1.004497</td>
      <td>0.994586</td>
      <td>0.997467</td>
      <td>0.999106</td>
      <td>0.998189</td>
      <td>1.000445</td>
      <td>0.997154</td>
      <td>1.000952</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.000293</td>
      <td>0.997559</td>
      <td>0.997272</td>
      <td>1.008893</td>
      <td>1.008204</td>
      <td>0.996506</td>
      <td>1.004391</td>
      <td>0.996658</td>
      <td>1.001606</td>
      <td>1.003066</td>
      <td>...</td>
      <td>0.996868</td>
      <td>0.996624</td>
      <td>1.001441</td>
      <td>0.995635</td>
      <td>1.000951</td>
      <td>1.001611</td>
      <td>0.996390</td>
      <td>0.995286</td>
      <td>1.001748</td>
      <td>1.005918</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.000186</td>
      <td>0.995998</td>
      <td>0.995491</td>
      <td>1.009860</td>
      <td>1.008443</td>
      <td>0.999443</td>
      <td>1.003346</td>
      <td>0.992760</td>
      <td>1.005025</td>
      <td>1.003060</td>
      <td>...</td>
      <td>0.999851</td>
      <td>0.995783</td>
      <td>1.004188</td>
      <td>0.992218</td>
      <td>1.001284</td>
      <td>1.000786</td>
      <td>0.998060</td>
      <td>0.993109</td>
      <td>1.003343</td>
      <td>1.008950</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.002284</td>
      <td>1.001620</td>
      <td>0.996325</td>
      <td>1.011357</td>
      <td>1.009942</td>
      <td>1.002166</td>
      <td>0.999931</td>
      <td>0.995803</td>
      <td>1.009673</td>
      <td>1.006885</td>
      <td>...</td>
      <td>0.990622</td>
      <td>0.994579</td>
      <td>1.004232</td>
      <td>0.996115</td>
      <td>1.000858</td>
      <td>1.002601</td>
      <td>1.000776</td>
      <td>0.995086</td>
      <td>1.003127</td>
      <td>1.008721</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2516</th>
      <td>1.455354</td>
      <td>1.573619</td>
      <td>1.456599</td>
      <td>2.094498</td>
      <td>1.459319</td>
      <td>2.612931</td>
      <td>1.468416</td>
      <td>1.283956</td>
      <td>1.902126</td>
      <td>1.262912</td>
      <td>...</td>
      <td>1.148716</td>
      <td>1.664003</td>
      <td>1.698365</td>
      <td>1.654188</td>
      <td>1.478686</td>
      <td>1.321187</td>
      <td>1.408349</td>
      <td>1.405076</td>
      <td>1.657433</td>
      <td>1.947684</td>
    </tr>
    <tr>
      <th>2517</th>
      <td>1.459013</td>
      <td>1.562994</td>
      <td>1.457970</td>
      <td>2.077916</td>
      <td>1.462866</td>
      <td>2.627174</td>
      <td>1.462494</td>
      <td>1.282870</td>
      <td>1.906259</td>
      <td>1.263754</td>
      <td>...</td>
      <td>1.148195</td>
      <td>1.664589</td>
      <td>1.692371</td>
      <td>1.647553</td>
      <td>1.466959</td>
      <td>1.311036</td>
      <td>1.406515</td>
      <td>1.406644</td>
      <td>1.656198</td>
      <td>1.939243</td>
    </tr>
    <tr>
      <th>2518</th>
      <td>1.458470</td>
      <td>1.569607</td>
      <td>1.464703</td>
      <td>2.077122</td>
      <td>1.459588</td>
      <td>2.616091</td>
      <td>1.459414</td>
      <td>1.291358</td>
      <td>1.915041</td>
      <td>1.259146</td>
      <td>...</td>
      <td>1.154817</td>
      <td>1.657351</td>
      <td>1.686598</td>
      <td>1.643334</td>
      <td>1.461565</td>
      <td>1.313421</td>
      <td>1.394855</td>
      <td>1.406403</td>
      <td>1.650951</td>
      <td>1.936361</td>
    </tr>
    <tr>
      <th>2519</th>
      <td>1.455402</td>
      <td>1.577636</td>
      <td>1.460174</td>
      <td>2.084871</td>
      <td>1.457154</td>
      <td>2.613720</td>
      <td>1.471895</td>
      <td>1.296612</td>
      <td>1.920291</td>
      <td>1.256831</td>
      <td>...</td>
      <td>1.154397</td>
      <td>1.667091</td>
      <td>1.690731</td>
      <td>1.637206</td>
      <td>1.455692</td>
      <td>1.319079</td>
      <td>1.402534</td>
      <td>1.405221</td>
      <td>1.650999</td>
      <td>1.957376</td>
    </tr>
    <tr>
      <th>2520</th>
      <td>1.455752</td>
      <td>1.577409</td>
      <td>1.469789</td>
      <td>2.079659</td>
      <td>1.462849</td>
      <td>2.605491</td>
      <td>1.479511</td>
      <td>1.297100</td>
      <td>1.911170</td>
      <td>1.256758</td>
      <td>...</td>
      <td>1.154269</td>
      <td>1.661380</td>
      <td>1.700357</td>
      <td>1.635398</td>
      <td>1.462349</td>
      <td>1.317865</td>
      <td>1.407798</td>
      <td>1.407198</td>
      <td>1.639020</td>
      <td>1.959057</td>
    </tr>
  </tbody>
</table>
<p>2521 rows × 500 columns</p>
</div>




```python
# Plot simulation outcomes
line_plot_ten = MC_ten_year.plot_simulation()
```


    
![png](output_42_0.png)
    



```python
# Plot probability distribution and confidence intervals
dist_plot_ten = MC_ten_year.plot_distribution()
```


    
![png](output_43_0.png)
    



```python
# Fetch summary statistics from the Monte Carlo simulation results
tbl_ten = MC_ten_year.summarize_cumulative_return()

# Print summary statistics
print(tbl_ten)
```

    count           500.000000
    mean              1.539730
    std               0.289346
    min               0.879632
    25%               1.326615
    50%               1.518143
    75%               1.697223
    max               2.605491
    95% CI Lower      1.043443
    95% CI Upper      2.165607
    Name: 2520, dtype: float64



```python
# Set initial investment
initial_investment = 20000 * 3

# Use the lower and upper `95%` confidence intervals to calculate the range of the possible outcomes of our $60,000
ci_lower_ten = round(tbl_ten[8] * initial_investment,2)
ci_upper_ten = round(tbl_ten[9] * initial_investment,2)

# Print results
print(f"There is a 95% chance that an initial investment of ${initial_investment} in the portfolio"
      f" over the next 10 years will end within in the range of"
      f" ${ci_lower_ten} and ${ci_upper_ten}")
```

    There is a 95% chance that an initial investment of $60000 in the portfolio over the next 10 years will end within in the range of $62606.55 and $129936.44

